
public class Connect_4 {

	
	static int slote [][]=new int[6][6];

	public static void createOrCheckTable()
	{
	 /*
	  * Draw a table
	  * 6*6 table
	  */
		 for (int i=0; i<6; i++)
		 {
		     for (int j=0; j<6; j++)
		     {
		         if (slote[i][j]==-1 || slote[i][j]==0)
		         {
		        	 //slot each array into -1
		             slote[i][j]=-1;
		             System.out.print(" "+slote[i][j]);
		         }
		         else
		         {
		        	 //Display the whole table
		             System.out.print("  "+slote[i][j]);
		
		         }
		     }
		     System.out.println();
		 }
	}
		
	public static void dropPiece(int xAxis,int yAxis, boolean playerTurn)
	{
		if (playerTurn== true)//player 1 drop
		{
			slote[yAxis][xAxis]=1;
		}
		else if(playerTurn==false)//player 2 drop
		{
			slote[yAxis][xAxis]=2;
		}
	}
	
	public static boolean checkWinner(int number, int xAxis,int yAxis)
	{
			int countVeOccurance=0;//count the given number by X axis
			int countHorOccurance=0;//count the given number by Y axis
			boolean checkWin=false;
			for ( int i=0; i<6; i++)
			{
				if (countVeOccurance<4 || countHorOccurance<4 )
				{
					if (slote[yAxis][i]==number)//loop x Axis 
					{
						countVeOccurance++;
					}
					else
					{
						if (countVeOccurance<4)
						{
							countVeOccurance=0;
						}
					}
					if (slote[i][xAxis]==number)//loop y Axis
					{
						countHorOccurance++;
					}
					else
					{
						if (countHorOccurance<4)
						{
							countHorOccurance=0;
						}		
					}
				}
				else
				{
					break;
				}
			}
			if(countVeOccurance>=4 || countHorOccurance>=4)//check if both x or y axis have 4 same number
			{
				checkWin=true;
			}
	
		return checkWin;		
	}
	
	
	public static void main(String [] args)
	{
		int [] countSlot={5,5,5,5,5,5};
		int xAxis=0;
		int yAxis=0;
		int Counter=0;
		int ranNum=0;
		boolean checkWins=false;
		boolean playerTurn=false;//true== player1's turn, false==player2's turn
		
		createOrCheckTable();

		do
		{
			xAxis=0+(int) (Math.random() * 6);
			yAxis=countSlot[xAxis];
			ranNum=0+(int) (Math.random() * 6);
			
			/*Given a random number and check which player start first
			 * 
			 */
			if (ranNum%2==0 && ranNum!=7)
			{
				playerTurn=true;//player 1
				ranNum=7;//7 are out of range of the random number means the program find out which player starts first

			}
			else
			{
				playerTurn=false;//player 2
				ranNum=7;//7 are out of range of the random number means program find out which player starts first
			}

			/*
			 * check which player starts first then 
			 * drop pieces and check who is the winner
			 */
			if (playerTurn==true && yAxis!=-1 && ranNum==7)
			{
				dropPiece(xAxis ,yAxis, playerTurn);//drop pices
				boolean checkWinner=checkWinner(1,xAxis ,yAxis);
				if (checkWinner)
				{
					System.out.println();
					createOrCheckTable();
					System.out.println("player one wins");
					break;//break if the the player wins
				}
				Counter++;
				countSlot[xAxis]=countSlot[xAxis]-1;
				playerTurn=false;
			}
			else if(playerTurn==false && yAxis!=-1 && ranNum==7)
			{
				dropPiece(xAxis ,yAxis, playerTurn);//drop pices
				boolean checkWinner=checkWinner(2,xAxis ,yAxis);//check who's the winner
				if (checkWinner)
				{
					System.out.println();
					createOrCheckTable();
					System.out.println("player two wins");
					break;//break if the the player wins
				}
				Counter++;
				countSlot[xAxis]=countSlot[xAxis]-1;
				playerTurn=true;
			}
			else
			{
				// skip a turn if colume is full
				if (playerTurn== true)
				{
					playerTurn=false;
				}
				else
				{
					playerTurn=true;
				}
			}
			System.out.println();
			createOrCheckTable();	
		}
		while (!checkWins && Counter!=36);
		
		if(Counter==36)//check if the table is full
		{
			System.out.println("No one Wins");
		}
	}
}
